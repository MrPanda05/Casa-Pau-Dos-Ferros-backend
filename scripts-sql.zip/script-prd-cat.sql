--Script produtos base
insert into api_product(name, description, price, amount, created_at , updated_at , image, reserved)
values
("Luvas de segurança", "Luvas de segurança 6 fios pigmentada", 30, 100, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, "media/product/1.webp", 0),
("Monitor Samsung CF390", "Monitor Samsung CF390 - 27' - FHD", 800, 50, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, "media/product/2.webp", 0),
("Mouse Logitech M90", "Mouse Logitech M90 - Óptico", 30, 200, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, "media/product/3.webp", 0),
("Sabão em pó OMO", "Sabão em pó OMO - 800g", 20, 100, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, "media/product/4.webp", 0),
("PlayStation 5 Sony", "PlayStation 5 Sony - 1Tb", 3900, 100, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, "media/product/5.webp", 0),
("Sabonete Líquido Protex", "Sabonete líquido Protex - 250ml", 10, 200, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, "media/product/6.png", 0),
("Sabonete Barra Protex", "Sabonete barra Protex - 85g", 10, 200, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, "media/product/7.jpg", 0),
("Shampoo Pantene", "Shampoo Pantene - 400ml", 30, 200, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, "media/product/8.jpg", 0),
("Teclado Mecânico KBM TG600" , "Teclado mecânico KBM TG600- Layout Internacional - 60%", 150, 200, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, "media/product/9.webp", 0),
("Limpador Multiuso Veja", "Limpador Multiuso Veja - 500ml", 20, 40, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, "media/product/10.webp", 0);

--Script categorias base
insert into api_category (name, description, created_at , updated_at)
values
("Eletrônicos", "Dispositivos eletrônicos", CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
("EPI", "Equipamentos de Proteção Individual", CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
("Informática", "Equipamentos de Informática", CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
("Limpeza", "Produtos de limpeza domiciliar", CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
("Higiêne", "Produtos de higiêne pessoal", CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

--Script adicionar produtos nas categorias
insert into api_productcategory(category_id, product_id)
values
(1, 2),
(1, 3),
(1, 5),
(1, 9),
(2, 1),
(3, 2),
(3, 3),
(3, 9),
(4, 4),
(4, 10),
(5, 6),
(5, 7);
